// Responsive navbar toggle (shared)
const navToggle = document.querySelector('.nav-toggle');
const navmenu = document.getElementById('navmenu');
if (navToggle) {
  navToggle.addEventListener('click', () => {
    const expanded = navToggle.getAttribute('aria-expanded') === 'true';
    navToggle.setAttribute('aria-expanded', String(!expanded));
    navmenu.classList.toggle('open');
  });
}
document.querySelectorAll('.nav-link').forEach(a => {
  a.addEventListener('click', () => {
    navmenu.classList.remove('open');
    navToggle?.setAttribute('aria-expanded','false');
  });
});

// Filter chips (only if present on page)
const chips = document.querySelectorAll('.chip');
const menuCards = document.querySelectorAll('.menu-card');
if (chips.length && menuCards.length) {
  chips.forEach(chip => chip.addEventListener('click', () => {
    chips.forEach(c => c.classList.remove('active'));
    chip.classList.add('active');
    const f = chip.dataset.filter;
    menuCards.forEach(card => {
      const tags = (card.dataset.tags || '').split(',');
      const show = f === 'all' || tags.includes(f);
      card.style.display = show ? '' : 'none';
    });
  }));
}

// Live search across menu items (if menu present)
const navSearch = document.getElementById('navSearch');
const searchResults = document.getElementById('searchResults');
if (navSearch && searchResults) {
  const items = [...document.querySelectorAll('.menu-card h4')].map(h => ({ name: h.textContent, el: h.closest('.menu-card') }));
  navSearch.addEventListener('input', () => {
    const q = navSearch.value.trim().toLowerCase();
    searchResults.innerHTML = '';
    if (!q) { searchResults.style.display = 'none'; items.forEach(i=>i.el?.style && (i.el.style.outline='')); return; }
    const matches = items.filter(i => i.name.toLowerCase().includes(q)).slice(0,6);
    matches.forEach(m => {
      const a = document.createElement('a');
      a.href = 'menu.html';
      a.role = 'option';
      a.textContent = m.name;
      searchResults.appendChild(a);
    });
    searchResults.style.display = matches.length ? 'block' : 'none';
  });
  document.addEventListener('click', (e) => {
    if (!searchResults.contains(e.target) && e.target !== navSearch) {
      searchResults.style.display = 'none';
    }
  });
}

// Add-to-cart demo feedback
document.querySelectorAll('.add-cart').forEach(btn => {
  btn.addEventListener('click', () => {
    btn.textContent = 'Added';
    btn.disabled = true;
    setTimeout(()=>{ btn.textContent='Add'; btn.disabled=false; }, 1200);
  });
});

// Login modal
const loginModal = document.getElementById('loginModal');
document.getElementById('openLogin')?.addEventListener('click', () => loginModal?.showModal && loginModal.showModal());
loginModal?.addEventListener('click', (e) => {
  const rect = loginModal.getBoundingClientRect();
  const inDialog = rect.top <= e.clientY && e.clientY <= rect.top + rect.height &&
                   rect.left <= e.clientX && e.clientX <= rect.left + rect.width;
  if (!inDialog) loginModal.close();
});

// Contact form (demo)
const contactForm = document.getElementById('contactForm');
const formStatus = document.getElementById('formStatus');
contactForm?.addEventListener('submit', (e) => {
  e.preventDefault();
  formStatus.textContent = 'Sending...';
  setTimeout(() => {
    formStatus.textContent = 'Thanks! We will confirm your reservation shortly.';
    contactForm.reset();
  }, 900);
});

// Newsletter
document.getElementById('newsletterForm')?.addEventListener('submit', (e) => {
  e.preventDefault();
  const email = document.getElementById('newsletterEmail').value;
  alert(`Subscribed: ${email}`);
  e.target.reset();
});

// Footer year
const y = document.getElementById('year');
if (y) y.textContent = new Date().getFullYear();

// Initial responsive state for nav
const mq = window.matchMedia('(max-width: 860px)');
function applyResponsive() {
  const toggle = document.querySelector('.nav-toggle');
  if (!toggle || !navmenu) return;
  if (mq.matches) {
    toggle.style.display = 'inline-flex';
    navmenu.classList.remove('open');
  } else {
    toggle.style.display = 'none';
    navmenu.classList.add('open');
  }
}
mq.addEventListener('change', applyResponsive);
applyResponsive();
// specials page interactions (keeps shared header behavior from script.js)
(function(){
  // Sticky tabs toggle sections
  const tabs = Array.from(document.querySelectorAll('.date-tabs .tab'));
  const sections = ['this-week','next-week','this-month'].map(id => document.getElementById(id));
  function showSection(id){
    sections.forEach(s => s.hidden = s.id !== id);
    tabs.forEach(t => t.classList.toggle('active', t.dataset.target === id));
    // Scroll reveal re-trigger on show
    document.querySelectorAll(`#${id} .card.special`).forEach((c,i)=> {
      setTimeout(()=> c.classList.add('revealed'), 60 * i);
    });
  }
  tabs.forEach(t => t.addEventListener('click', ()=> showSection(t.dataset.target)));
  showSection('this-week');

  // Scroll reveal for cards on load (IntersectionObserver)
  const io = new IntersectionObserver(entries=>{
    entries.forEach(e=>{
      if(e.isIntersecting){ e.target.classList.add('revealed'); io.unobserve(e.target); }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.card.special').forEach(c=> io.observe(c));

  // Parallax glow layer
  const fx = document.querySelector('.specials-hero .hero-fx');
  if (fx) {
    window.addEventListener('scroll', ()=>{
      const y = window.scrollY * 0.08;
      fx.style.transform = `translateY(${y}px)`;
    }, { passive:true });
  }

  // Toast for Add buttons (complements site demo)
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    toast.setAttribute('role','status');
    toast.setAttribute('aria-live','polite');
    toast.textContent = 'Added to cart';
    document.body.appendChild(toast);
  }
  function showToast(msg='Added to cart'){
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(()=> toast.classList.remove('show'), 1200);
  }
  document.querySelectorAll('.add-cart').forEach(btn => btn.addEventListener('click', ()=> showToast()));

})();
// specials.js

// Parallax: use rAF batching and passive scroll
(function(){
  const fx = document.querySelector('.specials-hero .hero-fx');
  if (!fx) return;
  let ticking = false;
  window.addEventListener('scroll', () => {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(() => {
      const y = window.scrollY * 0.08; // small multiplier
      fx.style.transform = `translateY(${y}px)`; // no layout reads
      ticking = false;
    });
  }, { passive: true });
})();
// Chef page: subtle parallax for glow layer
(function(){
  const fx = document.querySelector('.chef-hero-fx');
  if (!fx) return;
  let ticking = false;
  window.addEventListener('scroll', () => {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(() => {
      const y = window.scrollY * 0.08;
      fx.style.transform = `translateY(${y}px)`;
      ticking = false;
    });
  }, { passive: true });
})();
// Overlay toggling
const overlay = document.getElementById('contact-overlay');
const openBtn = document.getElementById('openOverlay');
const closeBtn = overlay?.querySelector('.close-overlay');
const toggleBtn = document.querySelector('.overlay-toggle');

function openOverlay() {
  overlay.classList.add('active');
  overlay.setAttribute('aria-hidden', 'false');
  toggleBtn?.setAttribute('aria-expanded', 'true');
}

function closeOverlayFn() {
  overlay.classList.remove('active');
  overlay.setAttribute('aria-hidden', 'true');
  toggleBtn?.setAttribute('aria-expanded', 'false');
}

openBtn?.addEventListener('click', openOverlay);
toggleBtn?.addEventListener('click', openOverlay);
closeBtn?.addEventListener('click', closeOverlayFn);
overlay?.addEventListener('click', (e) => {
  if (e.target === overlay) closeOverlayFn();
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && overlay?.classList.contains('active')) {
    closeOverlayFn();
  }
});
// Mobile nav toggle (reuses existing header structure)
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.nav-toggle');
  const menu = document.querySelector('.nav-menu');
  if (toggle && menu) {
    toggle.addEventListener('click', () => menu.classList.toggle('open'));
  }

  // Basic client-side validation
  const form = document.querySelector('.contact-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      const required = form.querySelectorAll('[required]');
      let ok = true;
      required.forEach((el) => {
        if (!el.value.trim()) {
          ok = false;
          el.classList.add('field-error');
          if (!document.querySelector('.form-error')) {
            const p = document.createElement('p');
            p.className = 'form-error';
            p.textContent = 'Please complete required fields.';
            form.prepend(p);
          }
        } else {
          el.classList.remove('field-error');
        }
      });
      if (!ok) e.preventDefault();
    });
  }
});
// script.js (enhanced)
// Shared state
const state = {
  cart: [],
  menu: null,
  specials: null,
  producers: null,
};

// Utils
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const money = n => `₹${n.toFixed(0)}`;
const trapFocus = (el) => {
  const f = 'a,button,input,select,textarea,[tabindex]:not([tabindex="-1"])';
  const focusables = () => $$(f, el).filter(x => !x.hasAttribute('disabled'));
  const onKey = (e) => {
    if (e.key !== 'Tab') return;
    const list = focusables();
    const first = list, last = list[list.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  };
  el.addEventListener('keydown', onKey);
  return () => el.removeEventListener('keydown', onKey);
};

// Persistent header behaviors
(function header() {
  const navToggle = $('.nav-toggle');
  const navmenu = $('#navmenu') || $('.nav-menu');
  if (navToggle && navmenu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navmenu.classList.toggle('open');
    });
    $$('.nav-link').forEach(a => a.addEventListener('click', () => {
      navmenu.classList.remove('open');
      navToggle?.setAttribute('aria-expanded', 'false');
    }));
  }
})();

// Cart drawer
(function cartDrawer() {
  const drawer = document.createElement('aside');
  drawer.id = 'cartDrawer';
  drawer.className = 'drawer';
  drawer.setAttribute('aria-hidden', 'true');
  drawer.innerHTML = `
    <div class="drawer-inner" role="dialog" aria-modal="true" aria-labelledby="cartTitle">
      <header class="drawer-head">
        <h3 id="cartTitle">Order</h3>
        <button class="close" aria-label="Close">×</button>
      </header>
      <div class="drawer-body"><ul class="cart-list"></ul></div>
      <footer class="drawer-foot">
        <div class="totals"><span>Subtotal</span><strong class="subtotal">₹0</strong></div>
        <button class="btn primary btn-checkout">Checkout</button>
      </footer>
    </div>`;
  document.body.appendChild(drawer);
  const inner = $('.drawer-inner', drawer);
  let untrap = null;
  const open = () => {
    drawer.classList.add('open');
    drawer.setAttribute('aria-hidden', 'false');
    untrap = trapFocus(inner);
    setTimeout(() => $('.close', drawer).focus(), 10);
    render();
  };
  const close = () => {
    drawer.classList.remove('open');
    drawer.setAttribute('aria-hidden', 'true');
    untrap?.();
  };
  drawer.addEventListener('click', (e) => { if (e.target === drawer) close(); });
  $('.close', drawer).addEventListener('click', close);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && drawer.classList.contains('open')) close(); });
  document.body.addEventListener('click', (e) => {
    const btn = e.target.closest('.add-cart');
    if (!btn) return;
    const id = btn.dataset.id;
    const item = state.menu?.items.find(i => i.id === id);
    if (!item) return;
    addToCart({ id: item.id, name: item.name, price: item.price, qty: 1 });
    toast('Added to cart');
  });
  document.body.addEventListener('click', (e) => {
    if (e.target.matches('.open-cart')) open();
  });
  function addToCart(line) {
    const existing = state.cart.find(l => l.id === line.id);
    if (existing) existing.qty += line.qty;
    else state.cart.push(line);
    render();
  }
  function render() {
    const ul = $('.cart-list', drawer);
    ul.innerHTML = '';
    let subtotal = 0;
    state.cart.forEach((l, idx) => {
      subtotal += l.price * l.qty;
      const li = document.createElement('li');
      li.className = 'cart-line';
      li.innerHTML = `
        <div>
          <strong>${l.name}</strong>
          <div class="muted">${money(l.price)} × 
            <button class="qty dec" data-i="${idx}" aria-label="Decrease">−</button>
            <span class="q">${l.qty}</span>
            <button class="qty inc" data-i="${idx}" aria-label="Increase">+</button>
          </div>
        </div>
        <button class="remove" data-i="${idx}" aria-label="Remove">×</button>`;
      ul.appendChild(li);
    });
    $('.subtotal', drawer).textContent = money(subtotal);
    ul.addEventListener('click', (e) => {
      if (e.target.classList.contains('remove')) {
        state.cart.splice(Number(e.target.dataset.i), 1);
        render();
      }
      if (e.target.classList.contains('inc')) {
        state.cart[Number(e.target.dataset.i)].qty++;
        render();
      }
      if (e.target.classList.contains('dec')) {
        const i = Number(e.target.dataset.i);
        state.cart[i].qty = Math.max(1, state.cart[i].qty - 1);
        render();
      }
    }, { once: true });
  }
  // Expose trigger button globally if needed
  const fab = document.createElement('button');
  fab.className = 'to-top open-cart';
  fab.setAttribute('aria-label', 'Open cart');
  fab.innerHTML = '🧺';
  document.body.appendChild(fab);
})();

// Toast
function toast(msg = 'Added to cart') {
  let t = $('#toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'toast';
    t.className = 'toast';
    t.setAttribute('role', 'status');
    t.setAttribute('aria-live', 'polite');
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 1200);
}

// Data loading + hydration
(async function dataLoad() {
  const needsMenu = !!document.body.dataset.pageMenu;
  const needsSpecials = !!document.body.dataset.pageSpecials;
  const needsProducers = !!document.body.dataset.pageProducers;
  try {
    if (needsMenu) {
      const res = await fetch('data/menu.json'); state.menu = await res.json(); renderMenu();
    }
    if (needsSpecials) {
      const res = await fetch('data/specials.json'); state.specials = await res.json(); renderSpecials();
    }
    if (needsProducers) {
      const res = await fetch('data/producers.json'); state.producers = await res.json(); renderProducers();
    }
  } catch(e) { console.warn('Data load failed', e); }
})();

// Menu rendering (progressive enhancement)
function renderMenu() {
  const grid = $('#menuGrid');
  if (!grid || !state.menu) return;
  grid.innerHTML = '';
  state.menu.items.forEach(i => {
    const card = document.createElement('article');
    card.className = `card menu-card`;
    card.dataset.tags = (i.tags || []).join(',');
    card.innerHTML = `
      <div class="photo"><img src="${i.img}" alt="${i.name}" loading="lazy"></div>
      <div class="card-body">
        <h4>${i.name}</h4>
        <p class="muted">${i.desc}</p>
        <div class="meta">
          ${(i.diet||[]).map(d=>`<span class="badge">${d}</span>`).join('')}
          ${i.available ? '' : '<span class="badge">Sold out</span>'}
        </div>
        <div class="row between">
          <strong class="price">${money(i.price)}</strong>
          <button class="btn small add-cart" data-id="${i.id}" ${i.available? '' : 'disabled'}>Add</button>
        </div>
      </div>`;
    grid.appendChild(card);
  });
  // Hook chips to data-tags (already in CSS)
}

// Specials rendering
function renderSpecials() {
  const slots = {
    'this-week': $('#this-week .grid'),
    'next-week': $('#next-week .grid'),
    'this-month': $('#this-month .grid')
  };
  if (!state.specials) return;
  Object.entries({ 'this-week': 'thisWeek', 'next-week': 'nextWeek', 'this-month': 'thisMonth' })
    .forEach(([id,key]) => {
      const list = state.specials[key] || [];
      const grid = slots[id];
      if (!grid) return;
      grid.innerHTML = '';
      list.forEach(s => {
        const card = document.createElement('article');
        card.className = 'card special revealed';
        card.innerHTML = `
          <div class="photo"><img src="${s.img}" alt="${s.name}" loading="lazy"></div>
          <div class="card-body">
            <h4>${s.name}</h4>
            <p class="muted">${s.desc}</p>
            <div class="meta">${(s.badges||[]).map(b=>`<span class="badge">${b}</span>`).join('')}</div>
            <div class="price">${money(s.price)}</div>
            <button class="btn small add-cart" data-id="${s.id}">Add</button>
          </div>`;
        grid.appendChild(card);
      });
    });
}

// Producers map + list
function renderProducers() {
  const list = $('#producerList');
  const map = $('#producerMap');
  if (!state.producers || !list) return;
  list.innerHTML = state.producers.map(p => `
    <article class="card">
      <h4>${p.name}</h4>
      <p class="muted">${p.role}</p>
      <div class="meta">${(p.season||[]).map(s=>`<span class="badge">${s}</span>`).join('')}</div>
      <a class="link" href="${p.site}" target="_blank" rel="noopener">Visit</a>
    </article>`).join('');
  // Lightweight map placeholder without external libs
  if (map) {
    map.innerHTML = '<div class="map-ph">Grower map (interactive layer optional)</div>';
  }
}

// Global search now indexes Menu + Journal (if present)
(function globalSearch() {
  const navSearch = $('#navSearch');
  const searchResults = $('#searchResults');
  if (!navSearch || !searchResults) return;
  function index() {
    const items = $$('.menu-card h4').map(h => ({ name: h.textContent, href: 'menu.html' }));
    const journal = $$('.journal-card h4').map(h => ({ name: h.textContent, href: h.closest('a')?.href || '#' }));
    return [...items, ...journal];
  }
  navSearch.addEventListener('input', () => {
    const q = navSearch.value.trim().toLowerCase();
    searchResults.innerHTML = '';
    if (!q) { searchResults.style.display = 'none'; return; }
    index().filter(i => i.name.toLowerCase().includes(q)).slice(0,6).forEach(m => {
      const a = document.createElement('a');
      a.href = m.href; a.role = 'option'; a.textContent = m.name;
      searchResults.appendChild(a);
    });
    searchResults.style.display = searchResults.childElementCount ? 'block' : 'none';
  });
  document.addEventListener('click', (e) => {
    if (!searchResults.contains(e.target) && e.target !== navSearch) searchResults.style.display = 'none';
  });
})();

// Reservation modal
(function reservationModal() {
  const modal = document.createElement('dialog');
  modal.className = 'modal';
  modal.innerHTML = `
    <form method="dialog" class="modal-inner resv-form">
      <button class="close" aria-label="Close">×</button>
      <h3>Reserve a Table</h3>
      <div class="row two">
        <label>Party
          <select name="party" required>
            ${Array.from({length:10},(_,i)=>`<option>${i+1}</option>`).join('')}
          </select>
        </label>
        <label>Date
          <input type="date" required>
        </label>
      </div>
      <div class="row two">
        <label>Time
          <select required>
            <option>6:00 PM</option><option>7:00 PM</option><option>8:00 PM</option>
          </select>
        </label>
        <label>Name
          <input type="text" required>
        </label>
      </div>
      <div class="row">
        <label>Email
          <input type="email" required>
        </label>
      </div>
      <div class="row">
        <button class="btn primary">Confirm</button>
      </div>
      <p class="muted">By sending, consent is given to be contacted about this inquiry.</p>
    </form>`;
  document.body.appendChild(modal);
  const closeBtn = $('.close', modal);
  let untrap = null;
  function open() { modal.showModal(); untrap = trapFocus($('.modal-inner', modal)); }
  function close() { modal.close(); untrap?.(); }
  closeBtn.addEventListener('click', (e) => { e.preventDefault(); close(); });
  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-open-reserve]')) { open(); }
  });
})();
// Scope everything to the login wrapper to avoid touching other pages/components
(() => {
  const root = document.querySelector('.auth-scope');
  if (!root) return;

  const $ = (sel) => root.querySelector(sel);

  const form = $('.auth-form');
  const emailEl = $('#auth-email');
  const passwordEl = $('#auth-password');
  const emailErr = $('#auth-email-error');
  const passwordErr = $('#auth-password-error');
  const toggleBtn = root.querySelector('[data-role="toggle-password"]');

  // Password toggle (scoped)
  const eyeOpen = '<svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 5c-7 0-11 7-11 7s4 7 11 7 11-7 11-7-4-7-11-7zm0 12a5 5 0 110-10 5 5 0 010 10zm0-2.2a2.8 2.8 0 100-5.6 2.8 2.8 0 000 5.6z"/></svg>';
  const eyeClosed = '<svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M3.53 2.47 2.47 3.53 5.3 6.36C3.67 7.57 2.34 9.16 1.5 12c2.1 6.7 9.09 8 10.5 8 1.02 0 5.85-.36 9.5-4.55l2.03 2.03 1.06-1.06L3.53 2.47zM12 6c5.23 0 8.92 3.49 10.5 6-1 2.08-2.59 3.87-4.58 5.03l-2.07-2.07A4.99 4.99 0 0 0 12 7a4.97 4.97 0 0 0-2.55.7l-1.5-1.5C9.1 6.07 10.49 6 12 6z"/></svg>';

  let visible = false;
  let hideTimer;

  toggleBtn?.addEventListener('click', () => {
    visible = !visible;
    passwordEl.type = visible ? 'text' : 'password';
    toggleBtn.setAttribute('aria-pressed', String(visible));
    toggleBtn.setAttribute('aria-label', visible ? 'Hide password' : 'Show password');
    toggleBtn.innerHTML = visible ? eyeOpen : eyeClosed;

    if (visible) {
      clearTimeout(hideTimer);
      hideTimer = setTimeout(() => {
        passwordEl.type = 'password';
        visible = false;
        toggleBtn.setAttribute('aria-pressed', 'false');
        toggleBtn.setAttribute('aria-label', 'Show password');
        toggleBtn.innerHTML = eyeClosed;
      }, 5000);
    } else {
      clearTimeout(hideTimer);
    }
  });

  // Validation (scoped)
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  function validateEmail() {
    if (emailEl.validity.valueMissing) {
      emailErr.textContent = 'Email is required.';
      emailErr.hidden = false;
      return false;
    }
    if (!emailPattern.test(emailEl.value)) {
      emailErr.textContent = 'Enter a valid email address.';
      emailErr.hidden = false;
      return false;
    }
    emailErr.textContent = '';
    emailErr.hidden = true;
    return true;
  }

  function validatePassword() {
    if (passwordEl.validity.valueMissing) {
      passwordErr.textContent = 'Password is required.';
      passwordErr.hidden = false;
      return false;
    }
    if (passwordEl.value.length < 8) {
      passwordErr.textContent = 'Password must be at least 8 characters.';
      passwordErr.hidden = false;
      return false;
    }
    passwordErr.textContent = '';
    passwordErr.hidden = true;
    return true;
  }

  emailEl.addEventListener('input', validateEmail);
  passwordEl.addEventListener('input', validatePassword);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const okEmail = validateEmail();
    const okPass = validatePassword();
    if (!okEmail) { emailEl.focus(); return; }
    if (!okPass) { passwordEl.focus(); return; }

    const payload = {
      email: emailEl.value.trim(),
      password: passwordEl.value,
      remember: root.querySelector('#auth-remember')?.checked || false
    };

    const btn = root.querySelector('.auth-primary-btn');
    btn.disabled = true;
    btn.textContent = 'Signing in…';

    try {
      // Replace with real API call
      // const res = await fetch('/api/auth/login', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(payload),
      //   credentials: 'include'
      // });
      // if (!res.ok) throw new Error('Invalid credentials');
      // location.href = '/dashboard';
      await new Promise(r => setTimeout(r, 800));
      alert('Logged in (demo) — wire to real backend.');
    } catch {
      passwordErr.textContent = 'Invalid email or password.';
      passwordErr.hidden = false;
    } finally {
      btn.disabled = false;
      btn.textContent = 'Sign in';
    }
  });
})();

